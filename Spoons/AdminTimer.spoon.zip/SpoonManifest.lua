return {
  name = "AdminTimer",
  version = "1.0",
  author = "Laurent Taupiac",
  homepage = "https://github.com/ltaupiac/admintimer",
  license = "BSD2",
  description = "Displays admin status and manages temporary elevation.",
}
