return {
  name = "AdminTimer",
  version = "1.0",
  author = "Laurent Taupiac",
  homepage = "https://github.com/ltaupiac/AdminTimer.spoon",
  license = "MIT",
  description = "Displays admin status and manages temporary elevation.",
}